#include "stdafx.h"

BOOL WINAPI _tDllMain(HINSTANCE, DWORD, LPVOID) {
	return TRUE;
}
