#ifndef _M68KD_H_
#define _M68KD_H_

char *M68KDisasm(unsigned short (*NW)(), unsigned int (*NL)());

#endif
