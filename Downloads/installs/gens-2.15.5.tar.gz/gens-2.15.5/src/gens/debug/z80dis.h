#ifndef _Z80DIS_H_
#define _Z80DIS_H_

int z80dis(unsigned char *buf, int *Counter, char str[128]);

#endif
